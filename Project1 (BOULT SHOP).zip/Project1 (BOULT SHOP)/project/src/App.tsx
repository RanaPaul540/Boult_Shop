import React, { useState } from 'react';
import { products, categories } from './data/products';
import { Product } from './types';

// Import context providers
import { CartProvider } from './context/CartContext';
import { WishlistProvider } from './context/WishlistContext';

// Import components
import Header from './components/Header';
import ProductList from './components/ProductList';
import ProductDetail from './components/ProductDetail';
import Cart from './components/Cart';
import Wishlist from './components/Wishlist';
import Footer from './components/Footer';

function App() {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);
  
  const handleProductSelect = (product: Product) => {
    setSelectedProduct(product);
  };
  
  const handleProductSelectById = (productId: number) => {
    const product = products.find(p => p.id === productId);
    if (product) {
      setSelectedProduct(product);
    }
  };
  
  const handleCloseProductDetail = () => {
    setSelectedProduct(null);
  };
  
  const toggleCart = () => {
    setIsCartOpen(!isCartOpen);
    if (!isCartOpen) {
      setIsWishlistOpen(false);
    }
  };
  
  const toggleWishlist = () => {
    setIsWishlistOpen(!isWishlistOpen);
    if (!isWishlistOpen) {
      setIsCartOpen(false);
    }
  };
  
  return (
    <CartProvider>
      <WishlistProvider>
        <div className="min-h-screen flex flex-col bg-gray-50">
          <Header 
            onCartClick={toggleCart} 
            onWishlistClick={toggleWishlist} 
          />
          
          <main className="flex-grow pt-24">
            <div className="container mx-auto px-4">
              <div className="mb-10 text-center">
                <h1 className="text-3xl md:text-4xl font-bold mb-4">Premium Tech Products</h1>
                <p className="text-gray-600 max-w-2xl mx-auto">
                  Discover the latest and greatest tech products at TechShop. From premium headphones to 
                  cutting-edge laptops, we've got everything you need to stay ahead in the digital world.
                </p>
              </div>
            </div>
            
            <ProductList 
              products={products} 
              categories={categories}
              onProductSelect={handleProductSelect} 
            />
          </main>
          
          <Footer />
          
          {/* Modals and Overlays */}
          {selectedProduct && (
            <ProductDetail 
              product={selectedProduct} 
              onClose={handleCloseProductDetail} 
            />
          )}
          
          <Cart 
            isOpen={isCartOpen} 
            onClose={() => setIsCartOpen(false)} 
          />
          
          <Wishlist 
            isOpen={isWishlistOpen} 
            onClose={() => setIsWishlistOpen(false)} 
            onProductSelect={handleProductSelectById}
          />
        </div>
      </WishlistProvider>
    </CartProvider>
  );
}

export default App;