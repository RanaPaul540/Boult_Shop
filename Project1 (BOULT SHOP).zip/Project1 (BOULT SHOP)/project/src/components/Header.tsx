import React, { useState, useEffect } from 'react';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import { ShoppingCart, Heart, Menu, X, Laptop, SearchIcon } from 'lucide-react';

interface HeaderProps {
  onCartClick: () => void;
  onWishlistClick: () => void;
}

const Header: React.FC<HeaderProps> = ({ onCartClick, onWishlistClick }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { getCartCount } = useCart();
  const { wishlistItems } = useWishlist();
  
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };
  
  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        isScrolled 
          ? 'bg-white shadow-md py-3' 
          : 'bg-transparent py-5'
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className="flex items-center mr-8">
              <Laptop className="h-8 w-8 text-indigo-600" />
              <span className="ml-2 text-xl font-bold">TechShop</span>
            </div>
            
            <nav className="hidden md:flex space-x-8">
              <a href="#" className="text-gray-800 hover:text-indigo-600 transition-colors duration-300">Home</a>
              <a href="#" className="text-gray-800 hover:text-indigo-600 transition-colors duration-300">Categories</a>
              <a href="#" className="text-gray-800 hover:text-indigo-600 transition-colors duration-300">Featured</a>
              <a href="#" className="text-gray-800 hover:text-indigo-600 transition-colors duration-300">Deals</a>
            </nav>
          </div>
          
          <div className="flex items-center space-x-4">
            <button
              className="p-2 text-gray-800 hover:text-indigo-600 transition-colors duration-300"
              aria-label="Search"
            >
              <SearchIcon size={20} />
            </button>
            
            <button 
              onClick={onWishlistClick}
              className="relative p-2 text-gray-800 hover:text-indigo-600 transition-colors duration-300"
              aria-label="Wishlist"
            >
              <Heart size={20} />
              {wishlistItems.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-indigo-600 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
                  {wishlistItems.length}
                </span>
              )}
            </button>
            
            <button 
              onClick={onCartClick}
              className="relative p-2 text-gray-800 hover:text-indigo-600 transition-colors duration-300"
              aria-label="Cart"
            >
              <ShoppingCart size={20} />
              {getCartCount() > 0 && (
                <span className="absolute -top-1 -right-1 bg-indigo-600 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
                  {getCartCount()}
                </span>
              )}
            </button>
            
            <button 
              onClick={toggleMobileMenu}
              className="md:hidden p-2 text-gray-800 hover:text-indigo-600 transition-colors duration-300"
              aria-label={isMobileMenuOpen ? "Close menu" : "Open menu"}
            >
              {isMobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile Menu */}
      <div 
        className={`md:hidden absolute top-full left-0 right-0 bg-white shadow-md transition-all duration-300 ${
          isMobileMenuOpen ? 'max-h-64 opacity-100' : 'max-h-0 opacity-0 overflow-hidden'
        }`}
      >
        <nav className="container mx-auto px-4 py-3 flex flex-col space-y-3">
          <a href="#" className="text-gray-800 hover:text-indigo-600 transition-colors duration-300 py-2">Home</a>
          <a href="#" className="text-gray-800 hover:text-indigo-600 transition-colors duration-300 py-2">Categories</a>
          <a href="#" className="text-gray-800 hover:text-indigo-600 transition-colors duration-300 py-2">Featured</a>
          <a href="#" className="text-gray-800 hover:text-indigo-600 transition-colors duration-300 py-2">Deals</a>
        </nav>
      </div>
    </header>
  );
};

export default Header;