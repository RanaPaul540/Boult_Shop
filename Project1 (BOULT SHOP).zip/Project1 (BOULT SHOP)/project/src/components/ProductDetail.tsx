import React, { useState } from 'react';
import { Product } from '../types';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import Rating from './Rating';
import { Heart, ShoppingCart, X, Minus, Plus, ChevronLeft } from 'lucide-react';

interface ProductDetailProps {
  product: Product;
  onClose: () => void;
}

const ProductDetail: React.FC<ProductDetailProps> = ({ product, onClose }) => {
  const [quantity, setQuantity] = useState(1);
  const { addToCart } = useCart();
  const { addToWishlist, removeFromWishlist, isInWishlist } = useWishlist();
  
  const handleAddToCart = () => {
    if (product.inStock) {
      for (let i = 0; i < quantity; i++) {
        addToCart(product);
      }
    }
  };
  
  const handleWishlistToggle = () => {
    if (isInWishlist(product.id)) {
      removeFromWishlist(product.id);
    } else {
      addToWishlist(product);
    }
  };
  
  const increaseQuantity = () => {
    setQuantity(prev => prev + 1);
  };
  
  const decreaseQuantity = () => {
    if (quantity > 1) {
      setQuantity(prev => prev - 1);
    }
  };
  
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div 
        className="fixed inset-0 bg-black bg-opacity-50 transition-opacity" 
        onClick={onClose}
      ></div>
      
      <div className="bg-white rounded-xl shadow-2xl overflow-hidden max-w-4xl w-full max-h-[90vh] overflow-y-auto relative z-10 animate-fadeIn">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-white shadow-md hover:bg-gray-100 transition-colors z-20"
          aria-label="Close"
        >
          <X size={20} />
        </button>
        
        <button 
          onClick={onClose}
          className="absolute top-4 left-4 p-2 rounded-full bg-white shadow-md hover:bg-gray-100 transition-colors z-20 flex items-center gap-1"
          aria-label="Back"
        >
          <ChevronLeft size={16} />
          <span className="text-sm">Back</span>
        </button>
        
        <div className="grid grid-cols-1 md:grid-cols-2">
          <div className="relative h-72 md:h-full">
            <img 
              src={product.image} 
              alt={product.name} 
              className="w-full h-full object-cover"
            />
            {!product.inStock && (
              <div className="absolute top-4 left-4 bg-red-500 text-white px-3 py-1 rounded-full text-sm">
                Out of Stock
              </div>
            )}
          </div>
          
          <div className="p-8">
            <div className="mb-2">
              <span className="text-sm text-gray-600">{product.category}</span>
            </div>
            
            <h2 className="text-2xl font-semibold text-gray-900 mb-2">{product.name}</h2>
            
            <div className="flex items-center gap-2 mb-4">
              <Rating value={product.rating} showValue size="md" />
              <span className="text-sm text-gray-500">
                ({product.reviews.length} reviews)
              </span>
            </div>
            
            <p className="text-gray-600 mb-6">{product.description}</p>
            
            <div className="text-2xl font-bold mb-6">${product.price.toFixed(2)}</div>
            
            <div className="flex items-center gap-4 mb-8">
              <div className="flex items-center rounded-lg overflow-hidden border border-gray-300">
                <button 
                  onClick={decreaseQuantity}
                  disabled={quantity <= 1}
                  className="p-2 bg-gray-100 hover:bg-gray-200 transition-colors"
                >
                  <Minus size={16} />
                </button>
                <span className="px-4">{quantity}</span>
                <button 
                  onClick={increaseQuantity}
                  className="p-2 bg-gray-100 hover:bg-gray-200 transition-colors"
                >
                  <Plus size={16} />
                </button>
              </div>
              
              <button
                onClick={handleAddToCart}
                disabled={!product.inStock}
                className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-lg ${
                  product.inStock 
                    ? 'bg-indigo-600 hover:bg-indigo-700 text-white' 
                    : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                } transition-colors duration-300`}
              >
                <ShoppingCart size={18} />
                <span>Add to Cart</span>
              </button>
              
              <button
                onClick={handleWishlistToggle}
                className="p-3 rounded-lg border border-gray-300 hover:bg-gray-100 transition-colors"
                aria-label={isInWishlist(product.id) ? "Remove from wishlist" : "Add to wishlist"}
              >
                <Heart 
                  size={18} 
                  className={isInWishlist(product.id) ? "fill-rose-500 text-rose-500" : "text-gray-600"} 
                />
              </button>
            </div>
            
            <h3 className="font-semibold text-lg mb-3">Customer Reviews</h3>
            
            {product.reviews.length > 0 ? (
              <div className="space-y-4">
                {product.reviews.map(review => (
                  <div key={review.id} className="border-b border-gray-100 pb-4">
                    <div className="flex items-center gap-3 mb-2">
                      <img 
                        src={review.avatar} 
                        alt={review.user} 
                        className="w-8 h-8 rounded-full"
                      />
                      <div>
                        <div className="font-medium">{review.user}</div>
                        <div className="text-xs text-gray-500">{review.date}</div>
                      </div>
                    </div>
                    <Rating value={review.rating} size="sm" />
                    <p className="mt-2 text-gray-600 text-sm">{review.comment}</p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-500">No reviews yet.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;