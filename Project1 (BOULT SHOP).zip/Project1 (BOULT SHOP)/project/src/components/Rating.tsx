import React from 'react';

interface RatingProps {
  value: number;
  max?: number;
  size?: 'sm' | 'md' | 'lg';
  showValue?: boolean;
}

const Rating: React.FC<RatingProps> = ({ 
  value, 
  max = 5, 
  size = 'md',
  showValue = false
}) => {
  const roundedValue = Math.round(value * 2) / 2; // Round to nearest 0.5
  
  const sizeClasses = {
    sm: 'text-sm',
    md: 'text-base',
    lg: 'text-lg'
  };
  
  const renderStars = () => {
    const stars = [];
    
    for (let i = 1; i <= max; i++) {
      if (i <= roundedValue) {
        // Full star
        stars.push(
          <span key={i} className="text-amber-400">★</span>
        );
      } else if (i - 0.5 === roundedValue) {
        // Half star
        stars.push(
          <span key={i} className="text-amber-400">⯨</span>
        );
      } else {
        // Empty star
        stars.push(
          <span key={i} className="text-gray-300">★</span>
        );
      }
    }
    
    return stars;
  };
  
  return (
    <div className={`flex items-center ${sizeClasses[size]}`}>
      <div className="flex">{renderStars()}</div>
      {showValue && (
        <span className="ml-2 text-gray-600 font-medium">
          {value.toFixed(1)}
        </span>
      )}
    </div>
  );
};

export default Rating;