import React from 'react';
import { useWishlist } from '../context/WishlistContext';
import { useCart } from '../context/CartContext';
import { X, Heart, ShoppingCart } from 'lucide-react';

interface WishlistProps {
  isOpen: boolean;
  onClose: () => void;
  onProductSelect: (productId: number) => void;
}

const Wishlist: React.FC<WishlistProps> = ({ isOpen, onClose, onProductSelect }) => {
  const { wishlistItems, removeFromWishlist, clearWishlist } = useWishlist();
  const { addToCart } = useCart();
  
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      <div 
        className="fixed inset-0 bg-black bg-opacity-50 transition-opacity" 
        onClick={onClose}
      ></div>
      
      <div 
        className={`fixed inset-y-0 right-0 max-w-md w-full bg-white shadow-xl flex flex-col transform transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="flex items-center justify-between border-b border-gray-200 py-4 px-6">
          <div className="flex items-center gap-2">
            <Heart size={20} />
            <h2 className="text-lg font-semibold">Your Wishlist</h2>
            {wishlistItems.length > 0 && (
              <span className="bg-gray-100 text-gray-800 text-xs font-medium px-2.5 py-0.5 rounded-full">
                {wishlistItems.length} items
              </span>
            )}
          </div>
          <button
            onClick={onClose}
            className="p-2 text-gray-500 hover:text-gray-700 transition-colors duration-200"
            aria-label="Close wishlist"
          >
            <X size={20} />
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto p-6">
          {wishlistItems.length > 0 ? (
            <div className="space-y-4">
              {wishlistItems.map(item => (
                <div 
                  key={item.product.id} 
                  className="flex gap-4 py-4 border-b border-gray-100"
                >
                  <div 
                    className="h-20 w-20 flex-shrink-0 rounded-md overflow-hidden cursor-pointer"
                    onClick={() => {
                      onProductSelect(item.product.id);
                      onClose();
                    }}
                  >
                    <img 
                      src={item.product.image} 
                      alt={item.product.name} 
                      className="h-full w-full object-cover"
                    />
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <h3 
                      className="text-base font-medium text-gray-900 truncate cursor-pointer hover:text-indigo-600 transition-colors"
                      onClick={() => {
                        onProductSelect(item.product.id);
                        onClose();
                      }}
                    >
                      {item.product.name}
                    </h3>
                    <p className="mt-1 text-sm text-gray-500">
                      ${item.product.price.toFixed(2)}
                    </p>
                    
                    <div className="flex items-center justify-between mt-2">
                      <button 
                        onClick={() => {
                          if (item.product.inStock) {
                            addToCart(item.product);
                          }
                        }}
                        disabled={!item.product.inStock}
                        className={`flex items-center gap-1 text-sm py-1 px-2 rounded ${
                          item.product.inStock
                            ? 'text-indigo-600 hover:text-indigo-700'
                            : 'text-gray-400 cursor-not-allowed'
                        } transition-colors duration-200`}
                      >
                        <ShoppingCart size={14} />
                        <span>{item.product.inStock ? 'Add to Cart' : 'Out of Stock'}</span>
                      </button>
                      
                      <button
                        onClick={() => removeFromWishlist(item.product.id)}
                        className="text-gray-400 hover:text-gray-500 transition-colors duration-200"
                        aria-label="Remove item"
                      >
                        <X size={16} />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <Heart size={48} className="text-gray-300 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-1">Your wishlist is empty</h3>
              <p className="text-gray-500 mb-6">Save items you're interested in for later.</p>
              <button
                onClick={onClose}
                className="text-indigo-600 hover:text-indigo-700 font-medium transition-colors duration-200"
              >
                Browse Products
              </button>
            </div>
          )}
        </div>
        
        {wishlistItems.length > 0 && (
          <div className="border-t border-gray-200 p-6">
            <button
              onClick={clearWishlist}
              className="w-full px-4 py-3 text-sm font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors duration-200"
            >
              Clear Wishlist
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Wishlist;