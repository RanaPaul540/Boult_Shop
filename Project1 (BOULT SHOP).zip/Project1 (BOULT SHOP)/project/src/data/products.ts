import { Product } from '../types';

export const products: Product[] = [
  {
    id: 1,
    name: "Premium Wireless Headphones",
    description: "Experience audio like never before with our premium noise-cancelling wireless headphones. Featuring 40 hours of battery life and ultra-comfortable ear cups.",
    price: 299.99,
    category: "Audio",
    image: "https://images.pexels.com/photos/3394665/pexels-photo-3394665.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    rating: 4.8,
    inStock: true,
    reviews: [
      {
        id: 101,
        productId: 1,
        user: "Alex Johnson",
        avatar: "https://randomuser.me/api/portraits/men/32.jpg",
        rating: 5,
        comment: "Best headphones I've ever owned. The noise cancellation is incredible!",
        date: "2023-05-15"
      },
      {
        id: 102,
        productId: 1,
        user: "Samantha Williams",
        avatar: "https://randomuser.me/api/portraits/women/41.jpg",
        rating: 4.5,
        comment: "Great sound quality, but they're a bit tight on my head after a few hours.",
        date: "2023-06-22"
      }
    ]
  },
  {
    id: 2,
    name: "Smart 4K Ultra HD TV",
    description: "Transform your living room with this stunning 55-inch 4K Ultra HD Smart TV. Features Dolby Vision, HDR10, and built-in streaming apps.",
    price: 799.99,
    category: "Television",
    image: "https://images.pexels.com/photos/6782350/pexels-photo-6782350.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    rating: 4.6,
    inStock: true,
    reviews: [
      {
        id: 201,
        productId: 2,
        user: "Michael Chen",
        avatar: "https://randomuser.me/api/portraits/men/78.jpg",
        rating: 5,
        comment: "The picture quality is absolutely amazing. Worth every penny!",
        date: "2023-04-18"
      },
      {
        id: 202,
        productId: 2,
        user: "Jessica Smith",
        avatar: "https://randomuser.me/api/portraits/women/65.jpg",
        rating: 4,
        comment: "Great TV, but the user interface could be more intuitive.",
        date: "2023-05-30"
      }
    ]
  },
  {
    id: 3,
    name: "Professional DSLR Camera",
    description: "Capture life's moments with extraordinary clarity using our professional DSLR camera. Includes 24.2MP sensor, 4K video, and a versatile 18-55mm lens.",
    price: 1299.99,
    category: "Photography",
    image: "https://images.pexels.com/photos/90946/pexels-photo-90946.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    rating: 4.9,
    inStock: true,
    reviews: [
      {
        id: 301,
        productId: 3,
        user: "David Wilson",
        avatar: "https://randomuser.me/api/portraits/men/25.jpg",
        rating: 5,
        comment: "As a professional photographer, I can confidently say this camera delivers outstanding results.",
        date: "2023-03-14"
      },
      {
        id: 302,
        productId: 3,
        user: "Emily Rodriguez",
        avatar: "https://randomuser.me/api/portraits/women/33.jpg",
        rating: 4.5,
        comment: "Great for beginners and intermediates alike. Love the image quality!",
        date: "2023-06-05"
      }
    ]
  },
  {
    id: 4,
    name: "Ultra-thin Laptop",
    description: "The ultimate portable powerhouse. Featuring a high-resolution display, all-day battery life, and lightning-fast SSD storage in an ultra-thin design.",
    price: 1499.99,
    category: "Computers",
    image: "https://images.pexels.com/photos/3766115/pexels-photo-3766115.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    rating: 4.7,
    inStock: true,
    reviews: [
      {
        id: 401,
        productId: 4,
        user: "Thomas Brown",
        avatar: "https://randomuser.me/api/portraits/men/53.jpg",
        rating: 5,
        comment: "Incredibly fast and the battery lasts all day. Perfect for my work needs.",
        date: "2023-02-20"
      },
      {
        id: 402,
        productId: 4,
        user: "Laura Martinez",
        avatar: "https://randomuser.me/api/portraits/women/19.jpg",
        rating: 4,
        comment: "Great laptop, but it does get warm under heavy use.",
        date: "2023-04-12"
      }
    ]
  },
  {
    id: 5,
    name: "Smart Home Hub",
    description: "Control your entire home with a single device. Compatible with all major smart home products and voice assistants.",
    price: 149.99,
    category: "Smart Home",
    image: "https://images.pexels.com/photos/1034812/pexels-photo-1034812.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    rating: 4.5,
    inStock: true,
    reviews: [
      {
        id: 501,
        productId: 5,
        user: "Robert Lee",
        avatar: "https://randomuser.me/api/portraits/men/42.jpg",
        rating: 4.5,
        comment: "Easy to set up and works with all my existing smart devices.",
        date: "2023-05-08"
      },
      {
        id: 502,
        productId: 5,
        user: "Jennifer Garcia",
        avatar: "https://randomuser.me/api/portraits/women/57.jpg",
        rating: 4.5,
        comment: "Good device, but occasionally drops connection with some of my older smart bulbs.",
        date: "2023-06-17"
      }
    ]
  },
  {
    id: 6,
    name: "Premium Smartwatch",
    description: "Track your fitness, receive notifications, and more with our waterproof smartwatch featuring a vibrant always-on display and 7-day battery life.",
    price: 249.99,
    category: "Wearables",
    image: "https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    rating: 4.4,
    inStock: false,
    reviews: [
      {
        id: 601,
        productId: 6,
        user: "Christopher Davis",
        avatar: "https://randomuser.me/api/portraits/men/61.jpg",
        rating: 4,
        comment: "Good fitness tracking, but the sleep tracking could be more accurate.",
        date: "2023-03-29"
      },
      {
        id: 602,
        productId: 6,
        user: "Amanda Taylor",
        avatar: "https://randomuser.me/api/portraits/women/22.jpg",
        rating: 5,
        comment: "The battery life is amazing! I only charge it once a week.",
        date: "2023-05-11"
      }
    ]
  }
];

export const categories = [...new Set(products.map(product => product.category))];